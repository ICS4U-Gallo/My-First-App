public class LibraryApp {
    private static Library library = new Library();

    public static void main(String[] args) {
        System.out.println(library);
    }
}
